import json

def handler(event, _ctx):
    return {
        "statusCode": 200,
        "headers": {
            "content-type": "application/json",
            "access-control-allow-origin": "*",
            "access-control-allow-headers": "content-type,authorization",
            "access-control-allow-methods": "GET,POST,OPTIONS",
        },
        "body": json.dumps({"ok": True, "service": "pia-backend", "version": "mvp-1"}),
    }