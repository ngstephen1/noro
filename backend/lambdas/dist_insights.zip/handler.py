# backend/lambdas/get_insights/handler.py
from __future__ import annotations
import os, json, decimal
from typing import Any, Dict, List
import boto3
from boto3.dynamodb.conditions import Key
from pia_common.logging import get_logger

log = get_logger("insights")
DDB_TABLE = os.getenv("DDB_TABLE")
AWS_REGION = os.getenv("AWS_REGION") or os.getenv("AWS_DEFAULT_REGION") or "us-east-1"
ddb = boto3.resource("dynamodb", region_name=AWS_REGION)
table = ddb.Table(DDB_TABLE)

def _resp(status: int, body: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "statusCode": status,
        "headers": {
            "content-type": "application/json",
            "access-control-allow-origin": "*",
            "access-control-allow-headers": "content-type,authorization",
            "access-control-allow-methods": "GET,POST,OPTIONS",
        },
        "body": json.dumps(body, default=_json_default),
    }

def _json_default(o):
    if isinstance(o, decimal.Decimal):
        return float(o)
    raise TypeError

def handler(event, _ctx):
    if event.get("httpMethod") == "OPTIONS":
        return _resp(200, {"ok": True})
    try:
        qs = event.get("queryStringParameters") or {}
        user_id = (qs.get("user_id") or "dev-user").strip()
        limit = int(qs.get("limit") or 5)

        resp = table.query(
            KeyConditionExpression=Key("PK").eq(f"USER#{user_id}"),
            ScanIndexForward=False,
            Limit=limit,
        )
        items = resp.get("Items") or []
        out: List[Dict[str, Any]] = []
        for it in items:
            out.append({
                "ts": it.get("ts_iso") or it.get("SK"),
                "summary": it.get("summary_text", ""),
                "next_actions": it.get("next_actions", []),
                "confidence": float(it.get("confidence", 0.7)),
            })
        return _resp(200, {"ok": True, "items": out})
    except Exception as e:
        log.info(json.dumps({"ok": False, "err": str(e)}))
        return _resp(500, {"ok": False, "error": str(e)})