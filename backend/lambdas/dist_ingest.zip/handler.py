# handler.py - POST /context
from __future__ import annotations
import os, json, decimal
from typing import Any, Dict, List
import boto3

# use the shared utilities you already have
from pia_common.schema import validate
from pia_common.ddb import put_session_summary
from pia_common.logging import get_logger
from pia_common.bedrock import summarize_bedrock, summarize_stub

log = get_logger("ingest")

DDB_TABLE = os.getenv("DDB_TABLE")
USE_BEDROCK = os.getenv("USE_BEDROCK", "").lower() in {"1", "true", "yes", "on"}

def _resp(status: int, body: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "statusCode": status,
        "headers": {
            "content-type": "application/json",
            "access-control-allow-origin": "*",
            "access-control-allow-headers": "content-type,authorization",
            "access-control-allow-methods": "GET,POST,OPTIONS",
        },
        "body": json.dumps(body, default=_json_default),
    }

def _json_default(o):
    if isinstance(o, decimal.Decimal):
        return float(o)
    raise TypeError

def _sanitize(evt: Dict[str, Any]) -> Dict[str, Any]:
    evt = dict(evt)
    # tabs – only the fields we support
    tabs = []
    for t in evt.get("tabs", []) or []:
        if not isinstance(t, dict):
            continue
        t2 = {
            "title": (t.get("title") or "")[:300],
            "url_hash": (t.get("url_hash") or "")[:64],
            "text_sample": (t.get("text_sample") or "")[:4000],
        }
        tabs.append(t2)
    evt["tabs"] = tabs

    sig = evt.get("signals") or {}
    evt["signals"] = {
        "idle_sec": int(sig.get("idle_sec", 0) or 0),
        "calendar_busy": bool(sig.get("calendar_busy", False)),
        "slack_ping": bool(sig.get("slack_ping", False)),
    }

    priv = evt.get("privacy") or {}
    allowlist = priv.get("allowlist") or []
    if not isinstance(allowlist, list):
        allowlist = []
    evt["privacy"] = {"redacted": bool(priv.get("redacted", True)), "allowlist": [str(x) for x in allowlist][:50]}

    # requireds
    evt["user_id"] = str(evt.get("user_id") or "dev-user")
    evt["ts"] = str(evt.get("ts") or "")
    evt["event"] = str(evt.get("event") or "manual_capture")  # extension should send one of: manual_capture|interrupt_detected|periodic
    evt["active_app"] = str(evt.get("active_app") or "chrome")
    evt["correlation_id"] = str(evt.get("correlation_id") or f"c-{evt['user_id']}")
    return evt

def handler(event, _ctx):
    if event.get("httpMethod") == "OPTIONS":
        return _resp(200, {"ok": True})

    try:
        body = event.get("body") or "{}"
        payload_in = json.loads(body)
        payload = _sanitize(payload_in)
        validate("context_event", payload)

        # summarize
        if USE_BEDROCK:
            summary = summarize_bedrock(payload)
        else:
            summary = summarize_stub(payload)

        validate("session_summary", summary)

        wrote = False
        if DDB_TABLE:
            user_id = payload["user_id"]
            ts_iso = payload["ts"]
            tab_hashes = [t.get("url_hash", "") for t in payload.get("tabs", [])]
            raw_excerpt = (payload.get("tabs", [{}])[0].get("text_sample") or "")[:300]

            put_session_summary(
                user_id=user_id,
                ts_iso=ts_iso,
                correlation_id=summary["correlation_id"],
                summary_text=summary["summary"],
                confidence=summary["confidence"],
                next_actions=summary["next_actions"],
                tab_hashes=tab_hashes,
                raw_excerpt=raw_excerpt,
                ttl_days=30,
            )
            wrote = True

        log.info(json.dumps({"ok": True, "cid": summary["correlation_id"], "ddb": wrote}))
        return _resp(200, {"ok": True, "correlation_id": summary["correlation_id"]})
    except ValueError as ve:
        log.info(json.dumps({"ok": False, "err": str(ve)}))
        return _resp(400, {"ok": False, "error": str(ve)})
    except Exception as e:
        log.info(json.dumps({"ok": False, "err": f"internal: {e}"}))
        return _resp(500, {"ok": False, "error": "internal_error"})